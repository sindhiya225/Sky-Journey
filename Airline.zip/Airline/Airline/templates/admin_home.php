<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['email'] !== 'admin@gmail.com') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SkyJourney</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            min-height: 100vh;
            margin: 0;
            padding: 0;
        }
        .dashboard-container {
            padding-top: 50px;
            padding-bottom: 50px;
        }
        .dashboard-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }
        .card-header {
            background: linear-gradient(90deg, #007bff 0%, #00c4cc 100%);
            color: white;
            padding: 20px;
            text-align: center;
            border-bottom: none;
        }
        .card-header h2 {
            margin: 0;
            font-weight: 600;
            font-size: 2rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .card-body {
            padding: 40px;
        }
        .welcome-text {
            color: #333;
            font-size: 1.5rem;
            font-weight: 300;
            margin-bottom: 30px;
            text-align: center;
        }
        .btn-custom {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 15px 30px;
            font-size: 1.1rem;
            font-weight: 500;
            border-radius: 50px;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
            margin: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        .btn-primary-custom {
            background: linear-gradient(45deg, #007bff, #00c4cc);
            border: none;
            color: white;
        }
        .btn-primary-custom:hover {
            background: linear-gradient(45deg, #0056b3, #009fa8);
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }
        .btn-secondary-custom {
            background: linear-gradient(45deg, #6c757d, #adb5bd);
            border: none;
            color: white;
        }
        .btn-secondary-custom:hover {
            background: linear-gradient(45deg, #5a6268, #959ca4);
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }
        .btn-icon {
            margin-right: 10px;
            font-size: 1.2rem;
        }
        .action-buttons {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
        }
        .animate__fadeIn {
            animation: fadeIn 1s ease-in;
        }
        @keyframes fadeIn {
            0% { opacity: 0; transform: translateY(20px); }
            100% { opacity: 1; transform: translateY(0); }
        }
        @media (max-width: 768px) {
            .btn-custom {
                width: 100%;
                margin: 10px 0;
            }
        }
    </style>
</head>
<body>
    <div class="container dashboard-container">
        <div class="row justify-content-center">
            <div class="col-md-10 col-lg-8">
                <div class="dashboard-card animate__fadeIn">
                    <div class="card-header">
                        <h2><i class="fas fa-tachometer-alt me-2"></i>Admin Dashboard</h2>
                    </div>
                    <div class="card-body">
                        <div class="welcome-text">
                            <h4>Welcome, Admin!</h4>
                            <p class="text-muted">Manage SkyJourney with ease</p>
                        </div>
                        <div class="action-buttons">
                            <a href="staff.php" class="btn btn-primary-custom btn-custom">
                                <i class="fas fa-user-plus btn-icon"></i> Add New Staff
                            </a>
                            <a href="add_flight.php" class="btn btn-primary-custom btn-custom">
                                <i class="fas fa-plane btn-icon"></i> Add New Flight
                            </a>
                            <a href="add_airport.php" class="btn btn-primary-custom btn-custom">
                                <i class="fas fa-map-marker-alt btn-icon"></i> Add New Airport
                            </a>
                            <a href="add_flight_schedule.php" class="btn btn-primary-custom btn-custom">
                                <i class="fas fa-calendar-alt btn-icon"></i> Add Flight Schedule
                            </a>
                            <a href="set_fare.php" class="btn btn-primary-custom btn-custom">
                                <i class="fas fa-money-bill-wave btn-icon"></i> Add Fare
                            </a>
                        </div>
                        <div class="footer">
                            <a href="logout.php" class="btn btn-secondary-custom btn-custom">
                                <i class="fas fa-sign-out-alt btn-icon"></i> Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>