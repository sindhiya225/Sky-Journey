<?php
session_start();
require_once 'database_connect.php';

if (!isset($_SESSION['email']) || $_SESSION['email'] !== 'admin@gmail.com') {
    header("Location: login.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $airportName = trim($_POST['airport_name']);
        $location = trim($_POST['location']);
        $noOfTerminals = (int)$_POST['no_of_terminals'];

        $stmt = $conn->prepare("
            INSERT INTO Airport (Airport_Name, Location, No_Of_Terminals)
            VALUES (:name, :location, :terminals)
        ");
        $stmt->execute([
            ':name' => $airportName,
            ':location' => $location,
            ':terminals' => $noOfTerminals
        ]);

        $success = "Airport added successfully!";
        header("Refresh: 2; url=admin_home.php");
    } catch (PDOException $e) {
        $error = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SkyHigh Airlines - Add Airport</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            min-height: 100vh;
            margin: 0;
            padding: 0;
        }
        .form-container {
            padding-top: 50px;
            padding-bottom: 50px;
        }
        .form-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .form-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }
        .card-header {
            background: linear-gradient(90deg, #007bff 0%, #00c4cc 100%);
            color: white;
            padding: 20px;
            text-align: center;
            border-bottom: none;
            border-radius: 20px 20px 0 0;
        }
        .card-header h2 {
            margin: 0;
            font-weight: 600;
            font-size: 2rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .card-body {
            padding: 40px;
        }
        .form-label {
            font-weight: 500;
            color: #333;
        }
        .form-control {
            border-radius: 10px;
            padding: 12px;
            font-size: 1rem;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 8px rgba(0, 123, 255, 0.3);
        }
        .btn-custom {
            padding: 12px 25px;
            font-size: 1.1rem;
            font-weight: 500;
            border-radius: 50px;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        .btn-primary-custom {
            background: linear-gradient(45deg, #007bff, #00c4cc);
            border: none;
            color: white;
        }
        .btn-primary-custom:hover {
            background: linear-gradient(45deg, #0056b3, #009fa8);
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }
        .btn-secondary-custom {
            background: linear-gradient(45deg, #6c757d, #adb5bd);
            border: none;
            color: white;
        }
        .btn-secondary-custom:hover {
            background: linear-gradient(45deg, #5a6268, #959ca4);
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }
        .btn-icon {
            margin-right: 10px;
            font-size: 1.2rem;
        }
        .alert {
            border-radius: 10px;
            font-size: 1rem;
            margin-bottom: 20px;
        }
        .animate__fadeIn {
            animation: fadeIn 1s ease-in;
        }
        @keyframes fadeIn {
            0% { opacity: 0; transform: translateY(20px); }
            100% { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="container form-container">
        <div class="row justify-content-center">
            <div class="col-md-10 col-lg-8">
                <div class="form-card animate__fadeIn">
                    <div class="card-header">
                        <h2><i class="fas fa-map-marker-alt me-2"></i>Add New Airport</h2>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                        <?php endif; ?>
                        <?php if ($success): ?>
                            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
                        <?php endif; ?>

                        <form method="POST" action="add_airport.php">
                            <div class="mb-3">
                                <label for="airport_name" class="form-label"><i class="fas fa-building me-2"></i>Airport Name:</label>
                                <input type="text" id="airport_name" name="airport_name" class="form-control" required placeholder="e.g., JFK International">
                            </div>

                            <div class="mb-3">
                                <label for="location" class="form-label"><i class="fas fa-globe me-2"></i>Location:</label>
                                <input type="text" id="location" name="location" class="form-control" required placeholder="e.g., New York, USA">
                            </div>

                            <div class="mb-3">
                                <label for="no_of_terminals" class="form-label"><i class="fas fa-terminal me-2"></i>Number of Terminals:</label>
                                <input type="number" id="no_of_terminals" name="no_of_terminals" class="form-control" required min="1">
                            </div>

                            <div class="text-center mt-4">
                                <button type="submit" class="btn btn-primary-custom btn-custom">
                                    <i class="fas fa-save btn-icon"></i>Add Airport
                                </button>
                                <a href="admin_home.php" class="btn btn-secondary-custom btn-custom">
                                    <i class="fas fa-arrow-left btn-icon"></i>Back to Dashboard
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>