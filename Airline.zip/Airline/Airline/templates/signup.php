<?php
require_once 'database_connect.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    
    if (empty($email) || empty($password)) {
        $error = "Email and password are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters long.";
    } else {
        try {
            $stmt = $conn->prepare("SELECT email FROM users WHERE email = :email");
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            
            if ($stmt->rowCount() > 0) {
                $error = "Email already exists.";
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO users (email, hashed_password, is_active) VALUES (:email, :hashed_password, 1)");
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':hashed_password', $hashed_password);

                if ($stmt->execute()) {
                    $success = "User registered successfully. Redirecting to login...";
                    header("refresh:3;url=login.php");
                    exit();
                } else {
                    $error = "Error inserting data.";
                }
            }
        } catch(PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SkyJourney - Sign Up</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            min-height: 100vh;
            margin: 0;
            padding: 0;
        }
        .form-container {
            padding-top: 50px;
            padding-bottom: 50px;
        }
        .form-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .form-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }
        .card-header {
            background: linear-gradient(90deg, #007bff 0%, #00c4cc 100%);
            color: white;
            padding: 20px;
            text-align: center;
            border-bottom: none;
            border-radius: 20px 20px 0 0;
        }
        .card-header h2 {
            margin: 0;
            font-weight: 600;
            font-size: 2rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .card-body {
            padding: 40px;
        }
        .form-label {
            font-weight: 500;
            color: #333;
        }
        .form-control, .form-select {
            border-radius: 10px;
            padding: 12px;
            font-size: 1rem;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: #007bff;
            box-shadow: 0 0 8px rgba(0, 123, 255, 0.3);
        }
        .btn-custom {
            padding: 12px 25px;
            font-size: 1.1rem;
            font-weight: 500;
            border-radius: 50px;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        .btn-primary-custom {
            background: linear-gradient(45deg, #007bff, #00c4cc);
            border: none;
            color: white;
        }
        .btn-primary-custom:hover {
            background: linear-gradient(45deg, #0056b3, #009fa8);
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }
        .btn-icon {
            margin-right: 10px;
            font-size: 1.2rem;
        }
        .alert {
            border-radius: 10px;
            font-size: 1rem;
            margin-bottom: 20px;
        }
        .animate__fadeIn {
            animation: fadeIn 1s ease-in;
        }
        @keyframes fadeIn {
            0% { opacity: 0; transform: translateY(20px); }
            100% { opacity: 1; transform: translateY(0); }
        }
        .link-text {
            color: #007bff;
            text-decoration: none;
        }
        .link-text:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container form-container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="form-card animate__fadeIn">
                    <div class="card-header">
                        <h2><i class="fas fa-user-plus me-2"></i>Sign Up</h2>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($error)): ?>
                            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                        <?php endif; ?>
                        <?php if (isset($success)): ?>
                            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
                        <?php endif; ?>

                        <form method="POST" action="signup.php">
                            <div class="mb-3">
                                <label for="email" class="form-label"><i class="fas fa-envelope me-2"></i>Email Address:</label>
                                <input type="email" id="email" name="email" class="form-control" required placeholder="Enter your email">
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label"><i class="fas fa-lock me-2"></i>Password:</label>
                                <input type="password" id="password" name="password" class="form-control" required placeholder="Create a password">
                            </div>

                            <div class="text-center mt-4">
                                <button type="submit" class="btn btn-primary-custom btn-custom">
                                    <i class="fas fa-user-plus btn-icon"></i>Sign Up
                                </button>
                            </div>

                            <div class="text-center mt-3">
                                <p>Already have an account? <a href="login.php" class="link-text">Log in</a></p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>