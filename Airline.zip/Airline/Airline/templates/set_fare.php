<?php
session_start();
require_once 'database_connect.php';

if (!isset($_SESSION['email']) || $_SESSION['email'] !== 'admin@gmail.com') {
    header("Location: login.php");
    exit();
}

$error = '';
$success = '';

try {
    $schedStmt = $conn->prepare("
        SELECT fs.Flight_Sched_ID, f.Model, a1.Airport_Name AS Source, a2.Airport_Name AS Destination, fs.Date_Of_Departure
        FROM FlightSchedule fs
        JOIN Flight f ON fs.Flight_Num = f.Flight_Num
        JOIN Airport a1 ON fs.Source_Airport_ID = a1.Airport_ID
        JOIN Airport a2 ON fs.Destination_Airport_ID = a2.Airport_ID
    ");
    $schedStmt->execute();
    $schedules = $schedStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "Error fetching schedules: " . $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $flightSchedId = $_POST['flight_sched_id'];
        $economyPrice = (float)$_POST['economy_price'];
        $businessPrice = (float)$_POST['business_price'];
        $taxes = isset($_POST['taxes']) ? (float)$_POST['taxes'] : 0.00;
        $dayType = $_POST['day_type'];

        $conn->beginTransaction();

        $fareStmt = $conn->prepare("
            INSERT INTO Fare (Flight_Sched_ID, Class, Day_Type, Taxes, Final_Price)
            VALUES (:sched_id, :class, :day_type, :taxes, :price)
        ");

        $fareStmt->execute([
            ':sched_id' => $flightSchedId,
            ':class' => 'Economy',
            ':day_type' => $dayType,
            ':taxes' => $taxes,
            ':price' => $economyPrice + $taxes
        ]);

        $fareStmt->execute([
            ':sched_id' => $flightSchedId,
            ':class' => 'Business',
            ':day_type' => $dayType,
            ':taxes' => $taxes,
            ':price' => $businessPrice + $taxes
        ]);

        $conn->commit();
        $success = "Fares set successfully!";
        header("Refresh: 2; url=admin_home.php");
    } catch (PDOException $e) {
        $conn->rollBack();
        $error = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SkyHigh Airlines - Set Fare</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            min-height: 100vh;
            margin: 0;
            padding: 0;
        }
        .form-container {
            padding-top: 50px;
            padding-bottom: 50px;
        }
        .form-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .form-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }
        .card-header {
            background: linear-gradient(90deg, #007bff 0%, #00c4cc 100%);
            color: white;
            padding: 20px;
            text-align: center;
            border-bottom: none;
            border-radius: 20px 20px 0 0;
        }
        .card-header h2 {
            margin: 0;
            font-weight: 600;
            font-size: 2rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .card-body {
            padding: 40px;
        }
        .form-label {
            font-weight: 500;
            color: #333;
        }
        .form-control, .form-select {
            border-radius: 10px;
            padding: 12px;
            font-size: 1rem;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: #007bff;
            box-shadow: 0 0 8px rgba(0, 123, 255, 0.3);
        }
        .btn-custom {
            padding: 12px 25px;
            font-size: 1.1rem;
            font-weight: 500;
            border-radius: 50px;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        .btn-primary-custom {
            background: linear-gradient(45deg, #007bff, #00c4cc);
            border: none;
            color: white;
        }
        .btn-primary-custom:hover {
            background: linear-gradient(45deg, #0056b3, #009fa8);
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }
        .btn-secondary-custom {
            background: linear-gradient(45deg, #6c757d, #adb5bd);
            border: none;
            color: white;
        }
        .btn-secondary-custom:hover {
            background: linear-gradient(45deg, #5a6268, #959ca4);
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }
        .btn-icon {
            margin-right: 10px;
            font-size: 1.2rem;
        }
        .alert {
            border-radius: 10px;
            font-size: 1rem;
            margin-bottom: 20px;
        }
        .animate__fadeIn {
            animation: fadeIn 1s ease-in;
        }
        @keyframes fadeIn {
            0% { opacity: 0; transform: translateY(20px); }
            100% { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="container form-container">
        <div class="row justify-content-center">
            <div class="col-md-10 col-lg-8">
                <div class="form-card animate__fadeIn">
                    <div class="card-header">
                        <h2><i class="fas fa-money-bill-wave me-2"></i>Set Flight Fares</h2>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                        <?php endif; ?>
                        <?php if ($success): ?>
                            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
                        <?php endif; ?>

                        <form method="POST" action="set_fare.php">
                            <div class="mb-3">
                                <label for="flight_sched_id" class="form-label"><i class="fas fa-calendar-alt me-2"></i>Flight Schedule:</label>
                                <select id="flight_sched_id" name="flight_sched_id" class="form-select" required>
                                    <option value="">Select Flight Schedule</option>
                                    <?php foreach ($schedules as $schedule): ?>
                                        <option value="<?php echo $schedule['Flight_Sched_ID']; ?>">
                                            <?php echo htmlspecialchars("{$schedule['Model']} - {$schedule['Source']} to {$schedule['Destination']} on {$schedule['Date_Of_Departure']}"); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="day_type" class="form-label"><i class="fas fa-calendar-day me-2"></i>Day Type:</label>
                                <select id="day_type" name="day_type" class="form-select" required>
                                    <option value="Weekday">Weekday</option>
                                    <option value="Weekend">Weekend</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="economy_price" class="form-label"><i class="fas fa-money-bill me-2"></i>Economy Class Price (Base):</label>
                                <input type="number" id="economy_price" name="economy_price" class="form-control" required min="0" step="0.01">
                            </div>

                            <div class="mb-3">
                                <label for="business_price" class="form-label"><i class="fas fa-money-bill me-2"></i>Business Class Price (Base):</label>
                                <input type="number" id="business_price" name="business_price" class="form-control" required min="0" step="0.01">
                            </div>

                            <div class="mb-3">
                                <label for="taxes" class="form-label"><i class="fas fa-calculator me-2"></i>Taxes (Optional):</label>
                                <input type="number" id="taxes" name="taxes" class="form-control" min="0" step="0.01" value="0.00">
                            </div>

                            <div class="text-center mt-4">
                                <button type="submit" class="btn btn-primary-custom btn-custom">
                                    <i class="fas fa-save btn-icon"></i>Set Fares
                                </button>
                                <a href="admin_home.php" class="btn btn-secondary-custom btn-custom">
                                    <i class="fas fa-arrow-left btn-icon"></i>Back to Dashboard
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>