<?php
include 'database_connect.php'; // Include database connection

$source_location = $destination_location = $departure_date = $passenger_count = "";
$flights = [];
$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $source_location = $_POST['source_location'] ?? "";
    $destination_location = $_POST['destination_location'] ?? "";
    $departure_date = $_POST['departure_date'] ?? "";
    $passenger_count = $_POST['passenger_count'] ?? "1"; // Default to 1 if not provided

    if (!empty($source_location) && !empty($destination_location) && !empty($departure_date)) {
        try {
            $stmt = $conn->prepare("SELECT Airport_ID FROM Airport WHERE Location = :source_location");
            $stmt->execute(['source_location' => $source_location]);
            $source_airport = $stmt->fetch(PDO::FETCH_ASSOC);

            $stmt = $conn->prepare("SELECT Airport_ID FROM Airport WHERE Location = :destination_location");
            $stmt->execute(['destination_location' => $destination_location]);
            $destination_airport = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$source_airport || !$destination_airport) {
                $error_message = "No matching airports found for the given locations.";
            } else {
                $source_id = $source_airport['Airport_ID'];
                $destination_id = $destination_airport['Airport_ID'];

                $stmt = $conn->prepare("
                    SELECT fs.*, f.Model, a1.Airport_Name AS Source_Airport, 
                           a2.Airport_Name AS Destination_Airport
                    FROM FlightSchedule fs
                    JOIN Flight f ON fs.Flight_Num = f.Flight_Num
                    JOIN Airport a1 ON fs.Source_Airport_ID = a1.Airport_ID
                    JOIN Airport a2 ON fs.Destination_Airport_ID = a2.Airport_ID
                    WHERE fs.Source_Airport_ID = :source_id 
                      AND fs.Destination_Airport_ID = :destination_id 
                      AND fs.Date_Of_Departure = :departure_date
                ");
                $stmt->execute([
                    'source_id' => $source_id,
                    'destination_id' => $destination_id,
                    'departure_date' => $departure_date
                ]);

                $flights = $stmt->fetchAll(PDO::FETCH_ASSOC);

                if (empty($flights)) {
                    $error_message = "No flights found for the selected route and date.";
                }
            }
        } catch (PDOException $e) {
            $error_message = "Error: " . $e->getMessage();
        }
    } else {
        $error_message = "Please enter all search fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search Flights</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<header>
        <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
          <div class="container">
            <a class="navbar-brand fw-bold text-primary" href="#">
              <i class="bi bi-airplane-fill me-2"></i>SkyJourney
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
              <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                  <a class="nav-link" href="../templates/home1.html">Home</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="../templates/mybooking.html">My Bookings</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link active" href="../templates/review.html">Reviews</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="../templates/myprofile.php">My Profile</a>
              </li>          
                <li class="nav-item">
                  <a  class="nav-link" href="home.html">Log out</a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </header>
<div class="container mt-5">
    <h2 class="text-center">Search Flights</h2>
    
    <?php if (!empty($error_message)): ?>
        <p class="text-danger text-center"><?php echo $error_message; ?></p>
    <?php endif; ?>

    <form action="" method="POST">
        <div class="mb-3">
            <label>Source Location:</label>
            <input type="text" name="source_location" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Destination Location:</label>
            <input type="text" name="destination_location" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Departure Date:</label>
            <input type="date" name="departure_date" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Number of Passengers:</label>
            <input type="number" name="passenger_count" class="form-control" min="1" value="1" required>
        </div>

        <button type="submit" class="btn btn-primary w-100">Search Flights</button>
    </form>

    <?php if (!empty($flights)): ?>
        <table class="table table-striped mt-4">
            <thead class="table-dark">
                <tr>
                    <th>Flight Number</th>
                    <th>Model</th>
                    <th>Source</th>
                    <th>Destination</th>
                    <th>Departure Date</th>
                    <th>Departure Time</th>
                    <th>Arrival Time</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($flights as $flight): ?>
                    <tr>
                        <td><?php echo $flight['Flight_Num']; ?></td>
                        <td><?php echo $flight['Model']; ?></td>
                        <td><?php echo $flight['Source_Airport']; ?></td>
                        <td><?php echo $flight['Destination_Airport']; ?></td>
                        <td><?php echo $flight['Date_Of_Departure']; ?></td>
                        <td><?php echo $flight['Departure_Time']; ?></td>
                        <td><?php echo $flight['Arrival_Time']; ?></td>
                        <td>
                            <a href="Bookingtickets.php?flight_id=<?php echo $flight['Flight_Num']; ?>&passenger_count=<?php echo $passenger_count; ?>" class="btn btn-success btn-sm">Book</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
</body>
</html>
