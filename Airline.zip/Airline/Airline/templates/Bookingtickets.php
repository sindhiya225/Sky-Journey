<?php
include 'database_connect.php';

if (!isset($_GET['flight_id']) || !isset($_GET['passenger_count'])) {
    die("Invalid request.");
}

$flight_id = $_GET['flight_id'];
$passenger_count = (int) $_GET['passenger_count'];
$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $conn->beginTransaction();

        // Step 1: Insert Booking Record (No Passenger_ID yet)
        $stmt = $conn->prepare("INSERT INTO Booking (Flight_Sched_ID, Payment_Status) 
                                VALUES (:flight_id, 'Pending')");
        $stmt->execute(['flight_id' => $flight_id]);
        $booking_id = $conn->lastInsertId(); // Get Booking ID

        for ($i = 0; $i < $passenger_count; $i++) {
            // Step 2: Insert Passenger Details
            $stmt = $conn->prepare("INSERT INTO Passenger (Passenger_Name, Contact_Info, DOB, Meal_Preference, Seat_Preference, Gender) 
                                    VALUES (:name, :contact, :dob, :meal, :seat, :gender)");
            $stmt->execute([
                'name' => $_POST['passenger_name'][$i],
                'contact' => $_POST['contact_info'][$i],
                'dob' => $_POST['dob'][$i],
                'meal' => $_POST['meal_preference'][$i],
                'seat' => $_POST['seat_preference'][$i],
                'gender' => $_POST['gender'][$i]
            ]);
            $passenger_id = $conn->lastInsertId();

            // Step 3: Link Passenger to the Booking (First passenger is primary booker)
            $stmt = $conn->prepare("INSERT INTO BookingPassengers (Booking_ID, Passenger_ID, Is_Primary_Booker) 
                                    VALUES (:booking_id, :passenger_id, :is_primary)");
            $stmt->execute([
                'booking_id' => $booking_id,
                'passenger_id' => $passenger_id,
                'is_primary' => ($i == 0) ? 1 : 0 // First passenger is primary booker
            ]);
        }

        $conn->commit();
        header("Location: mybooking.html?success=1&booking_id=" . $booking_id);
        exit();
    } catch (PDOException $e) {
        $conn->rollBack();
        $error_message = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Your Flight</title>
    <link rel="stylesheet" href="styles.css"> <!-- Add your CSS file -->
    <style>
        /* General Page Styling */
        /* Navbar Styling */
.navbar {
    background-color: white !important;
    box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
    padding: 15px 0;
}

/* Navbar Container */
.navbar .container {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

/* Logo Styling */
.navbar-brand {
    font-size: 1.5rem;
    font-weight: bold;
    color: #007bff !important; /* Blue color */
    text-decoration: none;
}

/* Ensure navbar items are in a row */
.navbar-nav {
    display: flex;
    list-style: none;  /* Remove bullets */
    padding-left: 0;
    margin: 0;
}

/* Navbar Links */
.navbar-nav .nav-item {
    margin-left: 20px; /* Space between items */
}

.navbar-nav .nav-link {
    font-size: 1rem;
    color: black !important;
    font-weight: 500;
    text-decoration: none;
    transition: color 0.3s ease;
    padding: 5px 10px; /* Adds space around text */
}

/* Active Link */
.navbar-nav .nav-link.active {
    font-weight: bold;
    color: black !important;
}

/* Hover Effect */
.navbar-nav .nav-link:hover {
    color: #007bff !important; /* Blue on hover */
}

/* Mobile Fix (Force items in a row for large screens) */
@media (min-width: 992px) {
    .navbar-collapse {
        display: flex !important;
        justify-content: flex-end;
    }
}

/* Mobile View - Stack items properly */
@media (max-width: 991px) {
    .navbar-nav {
        display: block;
        text-align: center;
    }

    .navbar-nav .nav-item {
        margin: 10px 0;
    }
}

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        /* Form Container */
        .form-container {
            width: 90%;
            max-width: 600px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 30px;
            text-align: center;
        }

        h2 {
            color: #004080;
            margin-bottom: 20px;
        }

        /* Fieldset Styling */
        fieldset {
            border: 1px solid #ccc;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        legend {
            font-weight: bold;
            color: #004080;
        }

        /* Labels and Inputs */
        label {
            display: block;
            text-align: left;
            font-size: 14px;
            margin-bottom: 8px;
        }

        input, select {
            width: 95%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }
        
        /* Error Message */
        .error-message {
            color: red;
            font-weight: bold;
            margin-bottom: 15px;
        }

        /* Submit Button */
        button {
            width: 100%;
            background-color: #004080;
            color: white;
            padding: 12px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button:hover {
            background-color: #002b5e;
        }

        /* Back Link */
        .back-link {
            display: block;
            margin-top: 15px;
            color: #004080;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        .back-link:hover {
            color: #002b5e;
        }

        /* Responsive Design */
        @media (max-width: 600px) {
            .form-container {
                width: 95%;
            }
        }
    </style>
</head>
<body>

    <h2>Flight Booking</h2>
    
    <div class="form-container">
        <?php if ($error_message): ?>
            <p class="error-message"><?php echo $error_message; ?></p>
        <?php endif; ?>

        <form action="Bookingtickets.php?flight_id=<?php echo $flight_id; ?>&passenger_count=<?php echo $passenger_count; ?>" method="post">
            <?php for ($i = 0; $i < $passenger_count; $i++): ?>
                <fieldset>
                    <legend>Passenger <?php echo $i + 1; ?> Details</legend>
                    <label>Name: <input type="text" name="passenger_name[]" required></label>
                    <label>Contact Info: <input type="text" name="contact_info[]" required></label>
                    <label>Date of Birth: <input type="date" name="dob[]" required></label>
                    <label>Meal Preference: 
                        <select name="meal_preference[]">
                            <option value="Vegetarian">Vegetarian</option>
                            <option value="Non-Vegetarian">Non-Vegetarian</option>
                            <option value="Vegan">Vegan</option>
                        </select>
                    </label>
                    <label>Seat Preference: 
                        <select name="seat_preference[]">
                            <option value="Window">Window</option>
                            <option value="Aisle">Aisle</option>
                            <option value="Middle">Middle</option>
                        </select>
                    </label>
                    <label>Gender: 
                        <select name="gender[]">
                            <option value="M">Male</option>
                            <option value="F">Female</option>
                            <option value="O">Other</option>
                        </select>
                    </label>
                </fieldset>
            <?php endfor; ?>
            <button type="submit">Confirm Booking</button>
        </form>

        <a href="home1.html" class="back-link">Back to Home</a>
    </div>

</body>
</html>
