<?php
session_start();
require 'database_connect.php';

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Please log in to view your bookings.'); window.location.href='login.php';</script>";
    exit();
}

$user_id = $_SESSION['user_id']; // Logged-in user's ID

try {
    // Fetch passenger ID linked to the logged-in user
    $stmt = $conn->prepare("
        SELECT Passenger_ID FROM Passenger 
        WHERE Contact_Info = (SELECT email FROM users WHERE id = ?)
    ");
    $stmt->execute([$user_id]);
    $passenger = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$passenger) {
        die("No bookings found for this user.");
    }

    $passenger_id = $passenger['Passenger_ID'];

    // Fetch all bookings for this passenger
    $stmt = $conn->prepare("
        SELECT 
            B.Booking_ID, 
            FS.Date_Of_Departure, 
            FS.Departure_Time, 
            FS.Arrival_Time,
            SA.Seat_Number,
            F.Class,
            F.Final_Price,
            A1.Airport_Name AS Departure_Airport,
            A2.Airport_Name AS Destination_Airport,
            B.Payment_Status
        FROM Booking B
        JOIN FlightSchedule FS ON B.Flight_Sched_ID = FS.Flight_Sched_ID
        JOIN Airport A1 ON FS.Source_Airport_ID = A1.Airport_ID
        JOIN Airport A2 ON FS.Destination_Airport_ID = A2.Airport_ID
        LEFT JOIN SeatAllocation SA ON B.Booking_ID = SA.Booking_ID
        LEFT JOIN Fare F ON B.Fare_ID = F.Fare_ID
        WHERE B.Passenger_ID = ?
        ORDER BY FS.Date_Of_Departure DESC
    ");
    $stmt->execute([$passenger_id]);
    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bookings</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #eceffe;
        }
        .container {
            margin-top: 40px;
        }
        .booking-card {
            background: white;
            padding: 20px;
            margin-bottom: 15px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }
        .btn-review {
            background: #4361ee;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
        }
        .btn-review:hover {
            background: #3f37c9;
        }
    </style>
</head>
<body>

<!-- ✅ Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold text-primary" href="#"><i class="bi bi-airplane-fill me-2"></i>SkyJourney</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="home1.html">Home</a></li>
                <li class="nav-item"><a class="nav-link active" href="mybooking.php">My Bookings</a></li>
                <li class="nav-item"><a class="nav-link" href="review1.html">Reviews</a></li>
                <li class="nav-item"><a class="nav-link" href="myprofile.php">My Profile</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">Log out</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- ✅ Booking History Section -->
<div class="container">
    <h2 class="mb-4">Your Booking History</h2>

    <?php if (!empty($bookings)) : ?>
        <?php foreach ($bookings as $booking) : ?>
            <div class="booking-card">
                <h4>Flight: <?= htmlspecialchars($booking['Departure_Airport']) ?> → <?= htmlspecialchars($booking['Destination_Airport']) ?></h4>
                <p><strong>Date:</strong> <?= htmlspecialchars($booking['Date_Of_Departure']) ?></p>
                <p><strong>Departure Time:</strong> <?= htmlspecialchars($booking['Departure_Time']) ?></p>
                <p><strong>Arrival Time:</strong> <?= htmlspecialchars($booking['Arrival_Time']) ?></p>
                <p><strong>Class:</strong> <?= htmlspecialchars($booking['Class']) ?></p>
                <p><strong>Seat:</strong> <?= htmlspecialchars($booking['Seat_Number'] ?? 'Not Assigned') ?></p>
                <p><strong>Fare:</strong> $<?= htmlspecialchars($booking['Final_Price']) ?></p>
                <p><strong>Payment Status:</strong> <?= htmlspecialchars($booking['Payment_Status']) ?></p>
                <a href="write_review.php?booking_id=<?= htmlspecialchars($booking['Booking_ID']) ?>" class="btn-review">Write Review</a>
            </div>
        <?php endforeach; ?>
    <?php else : ?>
        <p class="text-muted">You have no bookings yet.</p>
    <?php endif; ?>

</div>

<!-- ✅ Footer -->
<footer class="bg-dark text-white text-center py-3 mt-4">
    <p class="mb-0">© 2025 SkyJourney. All rights reserved.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$stmt->closeCursor();
$conn = null;
?>
