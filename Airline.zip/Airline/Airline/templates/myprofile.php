<?php
session_start();
require_once 'database_connect.php'; // Include your PDO database connection file

// Redirect to login if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch user email from database using PDO
try {
    $stmt = $conn->prepare("SELECT email FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
    $stmt->execute();
    
    if ($stmt->rowCount() === 0) {
        // User not found, destroy session and redirect
        session_destroy();
        header("Location: login.php");
        exit();
    }
    
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    $email = htmlspecialchars($user['email']);
    
} catch(PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile | SkyJourney</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .profile-card {
            max-width: 600px;
            margin: 30px auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            background-color: white;
        }
        .profile-header {
            text-align: center;
            margin-bottom: 20px;
            color: #4361ee;
        }
        .profile-detail {
            padding: 10px 0;
            border-bottom: 1px solid #e9ecef;
        }
        .nav-link.active {
            font-weight: bold;
            color: #4361ee !important;
        }
        html, body {
    height: 100%;
    margin: 0;
    display: flex;
    flex-direction: column;
}

.content {
    flex: 1; /* Pushes the footer to the bottom */
}

footer {
    background-color: #212529;
    color: white;
    text-align: center;
    padding: 20px;
}
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold text-primary" href="#">
                <i class="bi bi-airplane-fill me-2"></i>SkyJourney
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home1.html">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="mybooking.php">My Bookings</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="review1.html">Reviews</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="myprofile.php">My Profile</a>
                    </li>          
                    <li class="nav-item">
                        <a class="nav-link" href="home.html">Log out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="profile-card">
            <h2 class="profile-header"><i class="bi bi-person-circle me-2"></i>My Profile</h2>
            
            <div class="profile-detail">
                <strong>Email:</strong> <?php echo $email; ?>
            </div>
            
            <div class="profile-detail">
                <strong>Account Type:</strong> Standard Member
            </div>
            <div class="profile-detail">
                <strong>Member Since:</strong> <?php echo date('F Y'); ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
<footer class="bg-dark text-white footer">
        <div class="container">
            <h5 class="mb-3">SkyJourney</h5>
            <p class="small">Your trusted partner for seamless air travel experiences worldwide.</p>
            <ul class="list-unstyled small">
                <li><a href="about.html" class="text-decoration-none text-white-50">About Us</a></li>
                <li><a href="contact.html" class="text-decoration-none text-white-50">Contact</a></li>
                <li><a href="support.html" class="text-decoration-none text-white-50">Support</a></li>
            </ul>
            <hr>
            <div class="text-center text-white-50 small">
                © 2025 SkyJourney. All rights reserved.
            </div>
        </div>
    </footer>
</html>